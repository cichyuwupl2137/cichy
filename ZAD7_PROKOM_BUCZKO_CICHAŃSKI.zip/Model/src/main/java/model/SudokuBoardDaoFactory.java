package model;

public class SudokuBoardDaoFactory {
    public Dao<SudokuBoard> getFileDao(String directoryPath) {
        return new FileSudokuBoardDao(directoryPath);
    }
}
