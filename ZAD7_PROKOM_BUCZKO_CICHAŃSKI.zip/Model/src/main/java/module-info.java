module model {
    requires org.apache.commons.lang3;
    requires java.desktop;

    exports model;

    opens model;
}