package view;

public class widok {
    // Pusta klasa
}