package org;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BacktrackingSudokuSolver implements SudokuSolver {
    private final Random random = new Random();

    @Override
    public void solve(SudokuBoard board) {
        solve(board, 0, 0);
    }

    public boolean solve(SudokuBoard board, int rzad, int kolumna) {
        if (rzad >= 9) { //koniec planszy
            return true;
        }

        if (board.get(rzad, kolumna) == 0) {
            List<Integer> liczby = new ArrayList<>();
            for (int i = 1; i <= 9; i++) {
                liczby.add(i);
            }
            Collections.shuffle(liczby, random);
            for (int liczba : liczby) {
                if (czyBezpieczne(board, rzad, kolumna, liczba)) {
                    board.set(rzad, kolumna, liczba);
                    if (solve(board, (rzad * 9 + kolumna + 1) / 9, (rzad * 9 + kolumna + 1) % 9)) {
                        return true;
                    }
                    board.set(rzad, kolumna, 0);
                }
            }
            return false;
        }
        //dla czesciowo uzupelnionego sudoku
        return solve(board, (rzad * 9 + kolumna + 1) / 9, (rzad * 9 + kolumna + 1) % 9);
    }

    private boolean czyBezpieczne(SudokuBoard board, int rzad, int kolumna, int liczba) {
        for (int i = 0; i < 9; i++) {
            if (board.get(rzad, i) == liczba || board.get(i, kolumna) == liczba) {
                return false;
            }
        }
        int startRzad = (rzad / 3) * 3;
        int startKol = (kolumna / 3) * 3;
        for (int r = startRzad; r < startRzad + 3; r++) {
            for (int k = startKol; k < startKol + 3; k++) {
                if (board.get(r, k) == liczba) {
                    return false;
                }
            }
        }
        return true;
    }
}