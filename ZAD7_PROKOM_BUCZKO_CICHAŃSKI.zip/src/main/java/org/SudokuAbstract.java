package org;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

public abstract class SudokuAbstract implements PropertyChangeListener {
    private final List<SudokuField> pola;

      public SudokuAbstract(SudokuField[] fields) {
            if (fields.length != 9) {
                throw new IllegalArgumentException("Struktura Sudoku musi zawierać 9 pól.");
            }

            this.pola = Arrays.asList(fields);

        for (SudokuField field : this.pola) {
            field.addPropertyChangeListener(this);
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        this.verify();

    }

    public List<SudokuField> getFields() {
        return this.pola;
    }

    public boolean verify() {
        Set<Integer> rozne = new HashSet<>();
        for (SudokuField field : pola) {
            int pole = field.getFieldValue();
            if (pole == 0) {
                continue;
            }
            if (rozne.contains(pole)) {
                return false;
            }
            rozne.add(pole);
        }
        return true;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("pola", pola)
                .toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SudokuAbstract that = (SudokuAbstract) o;

        return new EqualsBuilder().append(pola, that.pola).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37).append(pola).toHashCode();
    }
}