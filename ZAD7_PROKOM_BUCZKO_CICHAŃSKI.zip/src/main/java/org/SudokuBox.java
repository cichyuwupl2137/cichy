package org;

public class SudokuBox extends SudokuAbstract {
    public SudokuBox(SudokuField[] fields) {
        super(fields);
    }

   
}
