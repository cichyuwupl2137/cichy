package org;

public interface SudokuSolver {
    void solve(SudokuBoard board);
}