package org;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testy klasy SudokuAbstract i klas pochodnych")
public class SudokuAbstractTest {

    private SudokuColumn sudokuColumn;
    private SudokuRow sudokuRow;
    private SudokuBox sudokuBox;
    private SudokuField[] sudokuFields;

    @BeforeEach
    public void rozpocznij(){

        this.sudokuFields = new SudokuField[9];

        for (int i = 0; i < 9; i++) {
            sudokuFields[i] = new SudokuField();
            sudokuFields[i].setFieldValue(i+1);
        }
        sudokuBox = new SudokuBox(sudokuFields);
    }


    @Test
    @DisplayName("Test 1 klasa sudokuAbstract")
    public void testSudokuAbstract() {
        SudokuField[] sudokuFields2 = new SudokuField[8];
        assertThrows(IllegalArgumentException.class, () -> sudokuRow = new SudokuRow(sudokuFields2), "Struktura Sudoku musi zawierać 9 pól.");

        assertEquals(Arrays.asList(sudokuFields), sudokuBox.getFields());

        System.out.println("Test 1: getFields() oraz konstruktor SudokuAbstract działają poprawnie");
    }

    @Test
    @DisplayName("Test 2: sprawdzenie działania verify()")
    void  testVerify() {

        assertTrue(sudokuBox.verify());
        sudokuFields[1].setFieldValue(0);
        assertTrue(sudokuBox.verify());
        sudokuFields[1].setFieldValue(1);
        assertFalse(sudokuBox.verify());

        System.out.println("Test 2: verify() działa poprawnie");
    }

    @Test
    @DisplayName("Test 3 klasy dziedziczące")
    void  testSudoku() {
        sudokuColumn = new SudokuColumn(sudokuFields);
        sudokuRow = new SudokuRow(sudokuFields);
        System.out.println("Test 3: Klasy pochodne utworzone");
    }

    @Test
    @DisplayName("Test 4: Hashcode i equals")
    void testHashcode() {
        SudokuField[] sudokuFields2 = new SudokuField[9];
        for (int i = 0; i < 9; i++) {
            sudokuFields2[i] = new SudokuField();
            sudokuFields2[i].setFieldValue(i+1);
        }
        SudokuBox sudokuBox2 = new SudokuBox(sudokuFields2);
        SudokuBox sudokuBox3 = sudokuBox;

        assertTrue(sudokuBox.equals(sudokuBox));
        assertTrue(sudokuBox.equals(sudokuBox3));
        assertEquals(sudokuBox.hashCode(), sudokuBox3.hashCode());

        assertTrue(sudokuBox.equals(sudokuBox2));
        assertEquals(sudokuBox.hashCode(), sudokuBox2.hashCode());

        assertEquals(sudokuBox.equals(sudokuBox2), sudokuBox2.equals(sudokuBox));

        assertFalse(sudokuBox.equals(null));
        SudokuSolver solver = new BacktrackingSudokuSolver();
        assertFalse(sudokuBox.equals(solver));
        System.out.println("Test 4: Metoda equals i hashCode działaja poprawnie");
    }

    @Test
    @DisplayName("Test 5: toString")
    void testToString() {
        assertEquals(sudokuBox.toString().getClass(), "str".getClass());
        System.out.println("Test 5: Metoda toString tworzy string");
    }
}
