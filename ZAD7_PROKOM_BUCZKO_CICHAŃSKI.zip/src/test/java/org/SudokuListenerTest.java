package org;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testy wzorca Observer dla Sudoku")
public class SudokuListenerTest {

    private SudokuField field;
    private TestListener listener;

    private static class TestListener implements PropertyChangeListener {
        boolean notified = false;

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
            this.notified = true;
        }

        public void reset() {
            this.notified = false;
        }
    }

    @BeforeEach
    void rozpocznij() {
        field = new SudokuField();
        listener = new TestListener();
        field.addPropertyChangeListener(listener);
    }

    @Test
    @DisplayName("Testuje usunięcie Listenera")
    public void testListener1() {
        field.setFieldValue(5);
        assertTrue(listener.notified, "Listener powinien zostać powiadomiony o pierwszej zmianie.");
        listener.reset();
        field.removePropertyChangeListener(listener);
        field.setFieldValue(8);
        assertFalse(listener.notified, "Usunięty listener nie powinien zostać powiadomiony o zmianie.");
        System.out.println("Test 1 Listener przeszedł pomyślnie");
    }

    @Test
    @DisplayName("Testuje brak powiadomienia przy ustawianiu tej samej wartości")
    public void testListener2() {
        field.setFieldValue(7);
        assertTrue(listener.notified, "Listener powinien zostać powiadomiony o pierwszej zmianie.");
        listener.reset();
        assertFalse(listener.notified, "Flaga powinna być zresetowana.");
        field.setFieldValue(7);
        assertFalse(listener.notified, "Listener nie powinien być powiadamiany, gdy wartość się nie zmienia.");
        System.out.println("Test 2 Listener przeszedł pomyślnie");

    }
}