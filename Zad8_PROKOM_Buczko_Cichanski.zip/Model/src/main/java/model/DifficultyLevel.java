package model;

import java.util.Random;

public enum DifficultyLevel {

    EASY(20),
    MEDIUM(40),
    HARD(60);

    private final int fieldsToRemove;
    private final Random random = new Random();

    DifficultyLevel(int fieldsToRemove) {
        this.fieldsToRemove = fieldsToRemove;
    }

    public void process(SudokuBoard board) {
        int removed = 0;
        while (removed < fieldsToRemove) {
            int row = random.nextInt(9);
            int col = random.nextInt(9);

            if (board.get(row, col) != 0) {
                board.set(row, col, 0);
                removed++;
            }
        }
    }
}