package model;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileSudokuBoardDao implements Dao<SudokuBoard> {

    private final String directoryPath;

    public FileSudokuBoardDao(String directoryPath) {
        this.directoryPath = directoryPath;
        try {
            Files.createDirectories(Path.of(directoryPath));
        } catch (IOException e) {
            throw new RuntimeException("Nie można utworzyć katalogu: " + directoryPath, e);
        }
    }

    @Override
    public SudokuBoard read(String name) {
        Path path = Paths.get(directoryPath, name);

        try (FileInputStream fileInputStream = new FileInputStream(path.toFile());
             ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {

            return (SudokuBoard) objectInputStream.readObject();

        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Błąd deserializacji: Nie znaleziono klasy SudokuBoard.", e);
        } catch (IOException e) {
            throw new RuntimeException("Błąd odczytu pliku: " + name, e);
        }
    }

    @Override
    public void write(String name, SudokuBoard obj) {
        Path path = Paths.get(directoryPath, name);

        try (FileOutputStream fileOutputStream = new FileOutputStream(path.toFile());
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {

            objectOutputStream.writeObject(obj);

        } catch (IOException e) {
            throw new RuntimeException("Błąd zapisu pliku: " + name, e);
        }
    }

    @Override
    public List<String> names() {
        try (Stream<Path> stream = Files.list(Path.of(directoryPath))) {
            return stream
                    .filter(file -> !Files.isDirectory(file))
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .toList();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    @Override
    public void close() throws Exception {
    }
}