package model;

public class SudokuBoardDaoFactory {

    private SudokuBoardDaoFactory() {
    }

    public static Dao<SudokuBoard> getFileDao(String directoryPath) {
        return new FileSudokuBoardDao(directoryPath);
    }
}
