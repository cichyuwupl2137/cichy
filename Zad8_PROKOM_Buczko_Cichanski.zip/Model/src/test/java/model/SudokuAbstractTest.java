package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testy klasy SudokuAbstract i klas pochodnych")
public class SudokuAbstractTest {

    private SudokuColumn sudokuColumn;
    private SudokuRow sudokuRow;
    private SudokuBox sudokuBox;
    private SudokuField[] sudokuFields;

    @BeforeEach
    public void rozpocznij(){

        this.sudokuFields = new SudokuField[9];

        for (int i = 0; i < 9; i++) {
            sudokuFields[i] = new SudokuField();
            sudokuFields[i].setFieldValue(i+1);
        }
        sudokuBox = new SudokuBox(sudokuFields);
    }


    @Test
    @DisplayName("Test 1 klasa sudokuAbstract")
    public void testSudokuAbstract() {
        SudokuField[] sudokuFields2 = new SudokuField[8];
        assertThrows(IllegalArgumentException.class, () -> sudokuRow = new SudokuRow(sudokuFields2), "Struktura Sudoku musi zawierać 9 pól.");

        assertEquals(Arrays.asList(sudokuFields), sudokuBox.getFields());

        System.out.println("Test 1: getFields() oraz konstruktor SudokuAbstract działają poprawnie");
    }

    @Test
    @DisplayName("Test 2: sprawdzenie działania verify()")
    void  testVerify() {

        assertTrue(sudokuBox.verify());
        sudokuFields[1].setFieldValue(0);
        assertTrue(sudokuBox.verify());
        sudokuFields[1].setFieldValue(1);
        assertFalse(sudokuBox.verify());

        System.out.println("Test 2: verify() działa poprawnie");
    }

    @Test
    @DisplayName("Test 3 klasy dziedziczące")
    void  testSudoku() {
        sudokuColumn = new SudokuColumn(sudokuFields);
        sudokuRow = new SudokuRow(sudokuFields);
        System.out.println("Test 3: Klasy pochodne utworzone");
    }

    @Test
    @DisplayName("Test 4: Hashcode i equals")
    void testHashcode() {
        SudokuField[] sudokuFields2 = new SudokuField[9];
        for (int i = 0; i < 9; i++) {
            sudokuFields2[i] = new SudokuField();
            sudokuFields2[i].setFieldValue(i+1);
        }
        SudokuBox sudokuBox2 = new SudokuBox(sudokuFields2);
        SudokuBox sudokuBox3 = sudokuBox;

        assertEquals(sudokuBox, sudokuBox);
        assertEquals(sudokuBox, sudokuBox3);
        assertEquals(sudokuBox.hashCode(), sudokuBox3.hashCode());

        assertEquals(sudokuBox, sudokuBox2);
        assertEquals(sudokuBox.hashCode(), sudokuBox2.hashCode());
        assertFalse(sudokuBox.equals(null), "Metoda equals powinna zwrócić false dla null");

        assertEquals(sudokuBox.equals(sudokuBox2), sudokuBox2.equals(sudokuBox));

        assertNotEquals(null, sudokuBox);
        SudokuSolver solver = new BacktrackingSudokuSolver();
        assertNotEquals(sudokuBox, solver);
        System.out.println("Test 4: Metoda equals i hashCode działaja poprawnie");
    }

    @Test
    @DisplayName("Test 5: toString")
    void testToString() {
        assertEquals(sudokuBox.toString().getClass(), "str".getClass());
        System.out.println("Test 5: Metoda toString tworzy string");
    }

    @Test
    @DisplayName("Test 6: Głęboka kopia SudokuRow (pokrycie metody clone w SudokuAbstract)")
    void testCloneSudokuRow() throws CloneNotSupportedException {
        SudokuField[] fields = new SudokuField[9];
        for (int i = 0; i < 9; i++) {
            fields[i] = new SudokuField();
            fields[i].setFieldValue(i + 1);
        }

        SudokuRow original = new SudokuRow(fields);

        SudokuRow clone = (SudokuRow) original.clone();

        assertNotSame(original, clone, "Klon musi być innym obiektem niż oryginał");

        assertEquals(original, clone, "Klon musi mieć taką samą zawartość (equals)");

        List<SudokuField> originalList = original.getFields();
        List<SudokuField> cloneList = clone.getFields();

        assertNotSame(originalList, cloneList, "Wewnętrzne listy pól muszą być różnymi obiektami");

        for (int i = 0; i < 9; i++) {
            assertNotSame(originalList.get(i), cloneList.get(i),
                    "Pole na indeksie " + i + " nie zostało sklonowane (to ten sam obiekt!)");

            assertEquals(originalList.get(i).getFieldValue(), cloneList.get(i).getFieldValue());
        }
    }
}
