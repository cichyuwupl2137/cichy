package view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import model.DifficultyLevel;

import java.io.IOException;

public class MenuController {

    @FXML
    private ComboBox<DifficultyLevel> difficultyComboBox;

    @FXML
    public void initialize() {
        difficultyComboBox.getItems().addAll(DifficultyLevel.values());
        difficultyComboBox.getSelectionModel().selectFirst();
    }

    @FXML
    private void onStartGame() {
        DifficultyLevel selectedLevel = difficultyComboBox.getValue();

        if (selectedLevel != null) {
            startGame(selectedLevel);
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Wybierz poziom trudności!");
            alert.showAndWait();
        }
    }

    private void startGame(DifficultyLevel level) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/primary.fxml"));
            Parent root = loader.load();

            SudokuController sudokuController = loader.getController();
            sudokuController.setDifficultyLevel(level);
            sudokuController.startNewGame();

            Stage stage = (Stage) difficultyComboBox.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sudoku - Gra (" + level + ")");
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}