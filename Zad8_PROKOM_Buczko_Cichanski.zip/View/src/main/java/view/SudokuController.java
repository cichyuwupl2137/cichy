package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.GridPane;
import javafx.util.converter.IntegerStringConverter;
import model.*;

import java.util.function.UnaryOperator;

public class SudokuController {

    @FXML
    private GridPane sudokuGrid;

    private SudokuBoard sudokuBoard;
    private final SudokuSolver solver = new BacktrackingSudokuSolver();

    private DifficultyLevel difficultyLevel = DifficultyLevel.EASY;

    @FXML
    public void initialize() {
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    @FXML
    private void onNewGame() {
        startNewGame();
    }

    public void startNewGame() {
        sudokuBoard = new SudokuBoard(solver);
        sudokuBoard.solveGame();

        difficultyLevel.process(sudokuBoard);

        fillGrid();
    }

    private void fillGrid() {
        sudokuGrid.getChildren().clear();

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                TextField textField = new TextField();
                textField.setPrefWidth(40);
                textField.setPrefHeight(40);
                textField.setAlignment(javafx.geometry.Pos.CENTER);

                int value = sudokuBoard.get(row, col);
                if (value != 0) {
                    textField.setText(String.valueOf(value));
                    textField.setEditable(false);
                    textField.setStyle("-fx-background-color: #e0e0e0; -fx-font-weight: bold;");
                } else {
                    textField.setStyle("-fx-background-color: white;");
                }

                addInputValidation(textField, row, col);
                sudokuGrid.add(textField, col, row);
            }
        }
    }

    private void addInputValidation(TextField field, int row, int col) {
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String text = change.getControlNewText();
            if (text.matches("[1-9]?")) {
                return change;
            }
            return null;
        };
        field.setTextFormatter(new TextFormatter<>(new IntegerStringConverter(), null, filter));

        field.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                try {
                    int val = Integer.parseInt(newValue);
                    sudokuBoard.set(row, col, val);
                } catch (NumberFormatException e) { /* ignore */ }
            } else {
                sudokuBoard.set(row, col, 0);
            }
        });
    }



    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}