package org;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.List;

public class SudokuBoard {
    private final SudokuField[][] board;
    private final SudokuSolver sudokuSolver;

    private final List<SudokuRow> rows = new ArrayList<>();
    private final List<SudokuColumn> columns = new ArrayList<>();
    private final List<SudokuBox> boxes = new ArrayList<>();

    public SudokuBoard(SudokuSolver solver) {
        this.board = new SudokuField[9][9];
        this.sudokuSolver = solver;

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                this.board[i][j] = new SudokuField();
            }
        }

        for (int i = 0; i < 9; i++) {
            rows.add(new SudokuRow(board[i]));
        }

        for (int i = 0; i < 9; i++) {
            SudokuField[] colFields = new SudokuField[9];
            for (int j = 0; j < 9; j++) {
                colFields[j] = board[j][i];
            }
            columns.add(new SudokuColumn(colFields));
        }

        for (int i = 0; i < 9; i++) {
            SudokuField[] boxFields = new SudokuField[9];
            int startRow = (i / 3) * 3;
            int startCol = (i % 3) * 3;
            int index = 0;
            for (int r = 0; r < 3; r++) {
                for (int c = 0; c < 3; c++) {
                    boxFields[index++] = board[startRow + r][startCol + c];
                }
            }
            boxes.add(new SudokuBox(boxFields));
        }
    }

    public int get(int row, int col) {
        if (row < 0 || row >= 9 || col < 0 || col >= 9) {
            throw new IllegalArgumentException("Poza zakresem 0-8.");
        }
        return board[row][col].getFieldValue();
    }

    public void set(int row, int col, int value) {
        if (row < 0 || row >= 9 || col < 0 || col >= 9) {
            throw new IllegalArgumentException("Poza zakresem 0-8.");
        }
        board[row][col].setFieldValue(value);
    }

    public boolean checkBoard() {
        for (SudokuRow row : rows) {
            if (!row.verify()) {
                return false;
            }
        }
        for (SudokuColumn col : columns) {
            if (!col.verify()) {
                return false;
            }
        }
        for (SudokuBox box : boxes) {
            if (!box.verify()) {
                return false;
            }
        }
        return true;
    }

    public SudokuRow getRow(int y) {
        return rows.get(y);
    }

    public SudokuColumn getColumn(int x) {
        return columns.get(x);
    }

    public SudokuBox getBox(int x, int y) {
        int boxIndex = (x / 3) + (y / 3) * 3;
        return boxes.get(boxIndex);
    }

    public void solveGame() {
        sudokuSolver.solve(this);
    }

    public boolean metodaDoCheckBoard() {
        return this.checkBoard();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("board", board)
                .append("sudokuSolver", sudokuSolver)
                .toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SudokuBoard that = (SudokuBoard) o;
        return new EqualsBuilder()
                .append(board, that.board)
                .append(sudokuSolver, that.sudokuSolver)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(board)
                .append(sudokuSolver)
                .toHashCode();
    }
}