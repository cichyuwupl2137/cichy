package org;

public class SudokuColumn extends SudokuAbstract {
    public SudokuColumn(SudokuField[] fields) {
        super(fields);
    }


}

