package org;

public class SudokuRow extends SudokuAbstract {

    public SudokuRow(SudokuField[] fields) {
        super(fields);
    }


}
