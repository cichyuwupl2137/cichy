package org;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testy klasy SudokuBoard")
class SudokuBoardTest {

    private SudokuBoard sudokuBoard;

    @BeforeEach
    void rozpocznij() {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        sudokuBoard = new SudokuBoard(solver);
    }

    @Test
    @DisplayName("Test 1: Czy get i set działają poprawnie")
    void testSetGet() {
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.get(9, 0), "Poza zakresem (row >= 9)");
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.get(-1, 0), "Poza zakresem (row < 0)");
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.get(0, 9), "Poza zakresem (col >= 9)");
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.get(0, -1), "Poza zakresem (col < 0)");

        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.set(9, 0, 5), "Poza zakresem (row >= 9)");
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.set(-1, 0, 5), "Poza zakresem (row < 0)");
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.set(0, 9, 5), "Poza zakresem (col >= 9)");
        assertThrows(IllegalArgumentException.class, () -> sudokuBoard.set(0, -1, 5), "Poza zakresem (col < 0)");

        assertDoesNotThrow(() -> {
            assertEquals(0, sudokuBoard.get(0, 0));
            sudokuBoard.set(2, 2, 4);
            assertEquals(4, sudokuBoard.get(2, 2));
            assertEquals(0, sudokuBoard.get(2, 1));
        });
        System.out.println("Test 1: Metody set i get działają poprawnie");
    }


    @Test
    @DisplayName("Test 2: Czy getColumn poprawnie zwraca kolumnę")
    void testGetColumn() {

        List<SudokuField> polaKolumny = sudokuBoard.getColumn(3).getFields();
        int[] wartosciKolumny = new int[9];
        int[] wartosciKolumny2 = new int[9];

        for (int y = 0; y < 9; y++) {
            wartosciKolumny[y] = polaKolumny.get(y).getFieldValue();
            wartosciKolumny2[y] = sudokuBoard.get(y,3);
        }

        assertArrayEquals(wartosciKolumny, wartosciKolumny2);
        System.out.println("Test 2: Kolumna prawidłowo zwrócona.");
    }

    @Test
    @DisplayName("Test 3: Czy getRow poprawnie zwraca wiersz")
    void testGetRow() {

        List<SudokuField> polaWiersza = sudokuBoard.getRow(3).getFields();
        int[] wartosciWiersza = new int[9];
        int[] wartosciWiersza2 = new int[9];

        for (int x = 0; x < 9; x++) {
            wartosciWiersza[x] = polaWiersza.get(x).getFieldValue();
            wartosciWiersza2[x] = sudokuBoard.get(3,x);
        }

        assertArrayEquals(wartosciWiersza, wartosciWiersza2);
        System.out.println("Test 3: Wiersz prawidłowo zwrócony.");
    }

    @Test
    @DisplayName("Test 4: Czy getColumn poprawnie zwraca kolumnę")
    void testGetBox() {

        List<SudokuField> polaPodla = sudokuBoard.getBox(7,3).getFields();
        int[] wartosciPodla = new int[9];
        int[] wartosciPodla2 = new int[9];

        for (int i = 0; i < 9; i++) {
            wartosciPodla[i] = polaPodla.get(i).getFieldValue();
        }

        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                wartosciPodla2[3*y+x]=sudokuBoard.get(y+3,x+6);
            }
        }

        assertArrayEquals(wartosciPodla, wartosciPodla2);
        System.out.println("Test 4: Pudło prawidłowo zwrócone.");
    }

    @DisplayName("Test 5.1: checkBoard() zwraca true dla planszy rozwiązanej")
    @Test
    void testCheckBoard() {
        sudokuBoard.solveGame();
        assertTrue(sudokuBoard.metodaDoCheckBoard(),
                "Poprawnie rozwiązana plansza powinna przejść walidację.");
    }

    @DisplayName("Test 6: checkBoard wykrywa błąd w wierszu")
    @Test
    void testCheckBoardInvalidRow() {
        sudokuBoard.set(0, 0, 5);
        sudokuBoard.set(0, 1, 5);
        assertFalse(sudokuBoard.metodaDoCheckBoard(),
                "checkBoard powinno wykryć duplikat w wierszu.");
    }

    @DisplayName("Test 7: checkBoard wykrywa błąd w KOLUMNIE")
    @Test
    void testCheckBoardInvalidColumn() {

        sudokuBoard.set(0, 0, 5);
        sudokuBoard.set(1, 0, 5);

        assertFalse(sudokuBoard.metodaDoCheckBoard(),
                "checkBoard powinno wykryć duplikat w kolumnie.");
    }

    @DisplayName("Test 8: checkBoard wykrywa błąd w boksie")
    @Test
    void testCheckBoardInvalidBox() {

        sudokuBoard.set(0, 0, 5);
        sudokuBoard.set(1, 1, 5);
        assertFalse(sudokuBoard.metodaDoCheckBoard(),
                "checkBoard powinno wykryć duplikat w boksie.");
    }

    @Test
    @DisplayName("Test 9: Hashcode i equals")
    void testHashcode() {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        SudokuBoard sudokuBoard2 = new SudokuBoard(solver);
        SudokuBoard sudokuBoard3 = sudokuBoard;

        assertTrue(sudokuBoard.equals(sudokuBoard));
        assertTrue(sudokuBoard.equals(sudokuBoard3));
        assertEquals(sudokuBoard.hashCode(), sudokuBoard3.hashCode());

        assertFalse(sudokuBoard.equals(sudokuBoard2));
        assertNotEquals(sudokuBoard.hashCode(), sudokuBoard2.hashCode());

        assertEquals(sudokuBoard.equals(sudokuBoard2), sudokuBoard2.equals(sudokuBoard));

        assertFalse(sudokuBoard.equals(null));
        assertFalse(sudokuBoard.equals(solver));
        System.out.println("Test 9: Metoda equals i hashCode działaja poprawnie");
    }

    @Test
    @DisplayName("Test 10: toString")
    void testToString() {
        assertEquals(sudokuBoard.toString().getClass(), "str".getClass());
        System.out.println("Test 10: Metoda toString tworzy string");
    }
}