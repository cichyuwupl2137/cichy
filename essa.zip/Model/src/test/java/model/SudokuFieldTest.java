package model;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Testy klasy SudokuField")
public class SudokuFieldTest {

    private SudokuField sudokuField;

    @BeforeEach
    void rozpocznij() {
        this.sudokuField = new SudokuField();
    }

    @Test
    @DisplayName("Test 1: Czy get i set działają poprawnie")
    void testSetGet() {
        assertThrows(IllegalArgumentException.class, () -> sudokuField.setFieldValue(-1), "Nieodpowiednia wartosc pola, podaj liczbe od 0 do 9");
        assertThrows(IllegalArgumentException.class, () -> sudokuField.setFieldValue(10), "Nieodpowiednia wartosc pola, podaj liczbe od 0 do 9");
        assertEquals(0, sudokuField.getFieldValue());
        sudokuField.setFieldValue(3);
        assertEquals(3, sudokuField.getFieldValue());
        System.out.println("Test 1: Metody set i get działają poprawnie");
    }

    @Test
    @DisplayName("Test 2: Equals i hashcode")
    void testEquals() {
        SudokuField sudokuField2 = new SudokuField();
        SudokuField sudokuField3 = sudokuField;

        assertTrue(sudokuField.equals(sudokuField));
        assertTrue(sudokuField.equals(sudokuField3));
        assertEquals(sudokuField.hashCode(), sudokuField3.hashCode());

        assertTrue(sudokuField.equals(sudokuField2));
        assertEquals(sudokuField.hashCode(), sudokuField2.hashCode());

        assertEquals(sudokuField.equals(sudokuField2), sudokuField2.equals(sudokuField));

        assertFalse(sudokuField.equals(null));

        SudokuSolver solver = new BacktrackingSudokuSolver();
        assertFalse(sudokuField.equals(solver));

        System.out.println("Test 2: Metoda equals i hashCode działaja poprawnie");
    }

    @Test
    @DisplayName("Test 3: toString")
    void testToString() {
        assertEquals(sudokuField.toString().getClass(), "str".getClass());
        System.out.println("Test 3: Metoda toString tworzy string");
    }
}
